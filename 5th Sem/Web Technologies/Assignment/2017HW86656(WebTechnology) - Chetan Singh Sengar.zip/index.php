<html>
<!-- 
    Table Creation in DataBase. 

    Query: 
    CREATE TABLE `bookdatabase` (
    `Book_ID` varchar(3000) NOT NULL,
    `Book_title` varchar(255) NOT NULL,
    `Author` varchar(255) DEFAULT NULL,
    `Price` int(11) DEFAULT NULL,
    `Rent` int(11) DEFAULT NULL,
    `Category` varchar(255) DEFAULT NULL
    ) ENGINE=InnoDB DEFAULT CHARSET=latin1;
    COMMIT;

 -->

<head>
    <title>
        Book Details Assignment
    </title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
</head>
<style>
    table {
        border: 1px;
        border-radius: 5px;
        border-color: black;
        border-style: solid;
        width: 100%;
        height: max-content;
        text-align: center;
    }

    div {
        margin: 15px;
    }

    input {
        width: 300px;
    }
</style>

<body>
    <h1>Assignment Name: Book Details</h1>
    <!--  -->
    <table>
        <tr>
            <td>
                <table>
                    <h2>Book Details</h2>
                    <tr>
                        <td>
                            <p><b>Book ID</p>
                        </td>
                        <td>
                            <p><b>Book_title</p>
                        </td>
                        <td>
                            <p><b>Author</b></p>
                        </td>
                        <td>
                            <p><b>Price</b></p>
                        </td>
                        <td>
                            <p><b>Rent</b></p>
                        </td>
                        <td>
                            <p><b>Category</b></p>
                        </td>
                        <td>
                            <p><b>Mark</b></p>
                        </td>
                        <td>
                            <p><b>Delete</b></p>
                        </td>
                    </tr>
                    <?php
                    $servername = "localhost";
                    $username = "root";
                    $password = "";
                    $dbname = "webtechnology";

                    // Create connection
                    $conn = new mysqli($servername, $username, $password, $dbname);

                    // Check connection
                    if ($conn->connect_error) {
                        die("Connection failed: " . $conn->connect_error);
                    }

                    $showTableQuery = "SELECT Book_ID, Book_title, Author, Price, Rent, Category FROM bookdatabase";
                    $result = $conn->query($showTableQuery);
                    $sn = 1;
                    if (isset($_POST['submitDelete'])) {
                        $checkKey = $_POST['checkBoxDelete'];
                        $checkQuery = $conn->query("DELETE from bookdatabase where Book_ID like '$checkKey'");
                    }

                    if ($result->num_rows > 0) {
                        // output data of each row
                        while ($row = $result->fetch_assoc()) {
                    ?>

                            <tr>
                                <form action="" method="post" role="form">
                                    <td><?php echo $row['Book_ID'] ?></td>
                                    <td><?php echo $row['Book_title'] ?></td>
                                    <td><?php echo $row['Author'] ?></td>
                                    <td><?php echo $row['Price'] ?></td>
                                    <td><?php echo $row['Rent'] ?></td>
                                    <td><?php echo $row['Category'] ?></td>
                                    <td><input type="checkbox" name="checkBoxDelete" value="<?php echo $row['Book_ID'] ?>" required></td>
                                    <td><input type="submit" name="submitDelete" class="btn btn-info"></td>
                                </form>
                            </tr>
                    <?php
                            $sn++;
                        }
                    } else {
                        echo "<tr> No Data Found </tr>";
                    }

                    $conn->close();
                    ?>
                </table>
            </td>
        </tr>
    </table>
    <!--  -->
    <br>
    <hr style="width: 70%; border: 1px solid black; border-radius: 5px;">
    <!--  -->
    <div class="container">
        <form action="BookDetails.php" method="post">
            <h2>Add New Details : </h2>
            <div class="row">
                <div class="col">
                    <input type="text" id="bid" name="bid" placeholder="Book ID(Ex: A5UI230)..">
                </div>
                <div class="col">
                    <input type="text" id="bTitle" name="bTitle" placeholder="Book Title..">
                </div>
                <div class="col">
                    <input type="text" id="bAuthor" name="bAuthor" placeholder="Book Author..">
                </div>
            </div>
            <div class="row">
                <div class="col">
                    <input type="number" id="bPrice" name="bPrice" placeholder="Book Price..">
                </div>
                <div class="col">
                    <input type="number" id="bRent" name="bRent" placeholder="Book Rent..">
                </div>
                <div class="col">
                    <input type="text" id="bCategory" name="bCategory" placeholder="Book Category..">
                </div>
            </div>
            <div class="row">
                <div class="col">
                    <input type="submit" value="Submit">
                </div>
            </div>
        </form>
    </div>
    <!--  -->
</body>

</html>